SERVIXO BRAND KIT

Brand: SERVIXO
Tagline: One Name. Every Repair.
Palette:
- Navy: #0B2D5B
- Orange: #F57C00
- White: #FFFFFF
- Light gray: #E6EDF5

Logo variants:
- servixo-logo-horizontal.svg/png: primary horizontal logo
- servixo-logo-stacked.svg/png: centered/stacked logo
- servixo-logo-reversed.svg/png: for dark backgrounds
- servixo-logo-monochrome.svg/png: single-color printing
- servixo-icon.svg/png: standalone emblem
- favicon.svg / favicon.ico / favicon-*.png: browser and app icons

Suggested HTML:
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="/favicon-180.png">

SVG files are scalable. The wordmark is text-based; convert text to outlines in a vector editor
if you need a font-independent print master.
